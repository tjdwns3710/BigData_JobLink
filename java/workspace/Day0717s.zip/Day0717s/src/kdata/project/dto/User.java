package kdata.project.dto;

public class User {

}
