select * from tab;

create table clients(
	id varchar2(10) primary key,
	pwd varchar2(10),
	name varchar2(10),
	profile varchar2(15),
	reg_date date default sysdate
);

insert into clients values(tjdwns,8844,�輺��);