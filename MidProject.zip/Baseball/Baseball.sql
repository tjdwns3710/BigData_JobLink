create table Team(
    tNum CHARACTER(2),
    tName varchar(9),
    HomeStd varchar(50),
    mName varchar(20),
    CONSTRAINT t_pk PRIMARY KEY (tNum)
);

drop table team;

create table player(
    pNum CHARACTER(4) primary key,
    pName varchar(20),
    pBackNum number(3),
    pAge number(3),
    tNum character(2) not null REFERENCES Team(tNum) ON DELETE CASCADE
);

drop table player;

create table Stadium(
    sNum character(1) primary key,
    sName varchar(50),
    sAddress varchar(100),
    occ integer
);

drop table Stadium;

create table SeatInfo(
    SeatCode character(2) primary key,
    sNum character(1) not null REFERENCES Stadium(sNum) ON DELETE CASCADE
);

drop table SeatInfo;

create table Game(
    gCode CHARACTER(5) primary key,
    gdate date,
    hTeam varchar(9),
    aTeam varchar(9),
    weather varchar(10),
    sNum CHARACTER(1) not null REFERENCES Stadium(sNum) ON DELETE CASCADE
);

drop table Game;

create table BallInfo(
    gCode CHARACTER(5) references Game(gCode),
    bOrder integer,
    bSeatCode character(2),
    HF character(1) default 'F',
    pNum character(4) not null references Player(pNum),
    CONSTRAINT bi_pk PRIMARY KEY (gCode, bOrder)
);

drop table BallInfo;


-------------------------------------------------------------

create table team(
tNum CHAR(2),
tName VARCHAR2(9),
HomeStd VARCHAR2(50),
mName VARCHAR2(20),

CONSTRAINT tNum_pk PRIMARY KEY (tNum)
);

create table player(
    pNum CHARACTER(4),
    pName varchar2(20),
    pBackNum number(3),
    pAge number(2),
    tNum CHAR(2) not null,
    pPos varchar2(12),
    CONSTRAINT pNum_pk PRIMARY KEY (pNum),
    CONSTRAINT tNum_fk FOREIGN KEY (tNum) REFERENCES team(tNum) ON DELETE CASCADE
);

create table Stadium(
    sNum CHAR(1),
    sName varchar2(50),
    sAddress varchar2(100),
    occ integer,
    CONSTRAINT sNum_pk PRIMARY KEY (sNum)
);

create table Game(
    gCode varchar2(3),
    gdate date default sysdate,
    hTeam varchar2(9),
    aTeam varchar2(9),
    weather varchar2(10),
    sNum CHARACTER(1) not null,
    CONSTRAINT gCode_pk PRIMARY KEY (gCode),
    CONSTRAINT sNum_fk FOREIGN KEY (sNum) REFERENCES Stadium(sNum) on delete cascade
);

create table BallInfo(
    gCode CHARACTER(5) not null,
    bOrder integer,
    bSeatCode character(2),
    HF character(1) default 'F' CHECK(HF in('H','F')),
    pNum character(4) not null,
    CONSTRAINT bi_pk PRIMARY KEY (gCode, bOrder),
    CONSTRAINT gCode_fk FOREIGN KEY (gCode) REFERENCES game(gCode) on DELETE CASCADE,
    CONSTRAINT pNum_fk FOREIGN KEY (pNum) REFERENCES player(pNum) on DELETE CASCADE
);

create table SeatInfo(
    SeatCode character(2) primary key,
    sNum character(1) not null REFERENCES Stadium(sNum) on delete cascade
);

--������ �ƴ� ������
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = 'LG';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = '�ؼ�';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = '��ȭ';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = '�λ�';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = 'KIA';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = '�Ｚ';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = 'KT';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = 'SK';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = '�Ե�';

select *
from(
select p.pnum, p.pname ,p.ppos, t.tname 
from player p join team t on p.tnum = t.tnum
where ppos not in '����')
where tname = 'NC';