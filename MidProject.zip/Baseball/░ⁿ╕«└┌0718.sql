create user project identified by 1234;

grant connect,resource to project;

conn project/1234