create table team(
tNum CHAR(2),
tName VARCHAR2(9),
HomeStd VARCHAR2(50),
mName VARCHAR2(20),

CONSTRAINT tNum_pk PRIMARY KEY (tNum)
);

create table player(
    pNum CHARACTER(4),
    pName varchar2(20),
    pBackNum number(3),
    pAge number(2),
    tNum CHAR(2) not null,
    pPos varchar2(12),
    CONSTRAINT pNum_pk PRIMARY KEY (pNum),
    CONSTRAINT tNum_fk FOREIGN KEY (tNum) REFERENCES team(tNum) ON DELETE CASCADE
);

create table Stadium(
    sNum CHAR(1),
    sName varchar2(50),
    sAddress varchar2(100),
    occ integer,
    CONSTRAINT sNum_pk PRIMARY KEY (sNum)
);

create table SeatInfo(
    SeatCode character(2),
    sNum character(1) not null,
    CONSTRAINT seatinfo_pk PRIMARY KEY (seatcode, snum),
    CONSTRAINT sNum_fk2 FOREIGN KEY (sNum) REFERENCES Stadium(sNum) on delete cascade
);

create table Game(
    gCode integer,
    gdate date default sysdate,
    hTeam varchar2(9),
    aTeam varchar2(9),
    weather varchar2(10),
    sNum CHARACTER(1) not null,
    CONSTRAINT gCode_pk PRIMARY KEY (gCode),
    CONSTRAINT sNum_fk FOREIGN KEY (sNum) REFERENCES Stadium(sNum) on delete cascade
);

create table BallInfo(
    gCode integer not null,
    bOrder integer,
    bSeatCode character(2),
    HF character(1) default 'F' CHECK(HF in('H','F')),
    pNum character(4) not null,
    CONSTRAINT bi_pk PRIMARY KEY (gCode, bOrder),
    CONSTRAINT gCode_fk FOREIGN KEY (gCode) REFERENCES game(gCode) on DELETE CASCADE,
    CONSTRAINT pNum_fk FOREIGN KEY (pNum) REFERENCES player(pNum) on DELETE CASCADE
);



drop table team;
drop table player;
drop table Stadium;
drop table SeatInfo;
drop table Game;
drop table BallInfo;